//books schema
const mongoose = require("mongoose");

const bookSchema = mongoose.Schema({
   title : {
      desc: "Book's title",
      type: String,
      required: true,
    },
    stock: {
      desc: "Qunatity",
      type: Number,
      required: true,
    },
    author: {
      desc: "author name",
      type: String,
      required: true,
    },
    category: {
      desc: "category",
      type: String,
      required: true,
    }, 
});

module.exports =  mongoose.model("Book", bookSchema);