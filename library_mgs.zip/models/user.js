//use schema
const mongoose = require("mongoose");
const { type } = require("os");
const userSchema = mongoose.Schema({
  fullName: {
    type: String,
    required: true,
  },

  address: {
    type : String,
    required : true,
  },

  mobNumber : {
    type:String,
    required : true
  },
  
  joined: { type: Date, default: Date.now() },
  bookCount:{
    type: Number,
    trim :true
  },
  

  bookIssued : []
});

module.exports = mongoose.model("User", userSchema);
