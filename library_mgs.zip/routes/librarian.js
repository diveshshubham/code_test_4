const appRouter = (app) => {
    const { check, validationResult } = require("express-validator/check"); //for validating inputs
    const Book = require('../models/book');
    const User = require('../models/user');


//************************************************************************************************************************
//**************************************Endpoint to add new book in database**********************************************
//************************************************************************************************************************ 

    app.post("/addbook", [
        check("title", "it's mandatory").not().isEmpty(),     ////////////////////////////////////////////////
        check("stock", "it's too short").not().isEmpty(),     //////////////// Validating Input //////////////
        check("author", "it's mandatory").not().isEmpty(),    ////////////////////////////////////////////////
        check("category", "it's mandatory").not().isEmpty()
        ], async (req, res) => {

        const errors = validationResult(req);
        if (!errors.isEmpty()) 
            {
                return res.status(400).json({ errors: errors.array() });
            }

        try {
            const new_book = new Book({
                title: req.body.title,
                stock: req.body.stock,
                author: req.body.author,
                category: req.body.category
            })
            await new_book.save().then((data) => {      //saving data in a book schema
                res.send(data);
            });
        }
        catch (err) {
            console.log(err);
            res.send({ message: "oops!something went wrong" });
        }
    });

//*************************************************************************************************************************************
//******************************** Endpoint to add new user or reader *****************************************************************
//************************************************************************************************************************************* 

    app.post("/adduser", [
        check("fullName", "it's mandatory").not().isEmpty(),      /////////////////////////////////////////////////
        check("address", "it's mandatory").not().isEmpty(),       ////////////////Validating input ////////////////
        check("mobNumber", "it's mandatory").not().isEmpty(),     /////////////////////////////////////////////////
    ], async (req, res) => {
        const errors = validationResult(req);

        if (!errors.isEmpty()) 
            {
                return res.status(400).json({ errors: errors.array() });
            }

        const { mobNumber } = req.body;
        try {
            let check = await User.findOne({ mobNumber });  //checking wheather user exist or not

            if (check) 
                {
                    res.send({ message: "user already exist" })
                }
            else{
            const new_user = new User({
            fullName: req.body.fullName,
            address: req.body.address,
            mobNumber: req.body.mobNumber,
            bookCount: req.body.bookCount,
            bookIssued: req.body.bookIssued
            })

            await new_user.save(); //saving data in user schema
            res.send({ message: "Bingo! you have successfully registerd" });}
        } catch (err) {
            console.log(err);
            res.send({ message: "oops!something went wrong" });
        }
    });

//*************************************************************************************************************************************
//******************************** Endpoint to get list of all books *****************************************************************
//************************************************************************************************************************************* 

    app.get("/allBooks", (req, res) => {
        Book.find().sort({ title: 1 }).then((data) => {
            res.send({ Allbooks: data });
        }).catch((err) => {
            res.send({ message: err.message || "something went worng" })
        });

    });

//*************************************************************************************************************************************
//******************************** Endpoint to get list all user   *****************************************************************
//************************************************************************************************************************************* 

    app.get("/allusers", (req, res) => {
        User.find().then((data) => {
            res.send(data);
        });
    });


//*************************************************************************************************************************************
//******************************** Endpoint to see your profile *****************************************************************
//************************************************************************************************************************************* 

    app.get("/yourProfile", (req, res) => {
        if (req.body.mobNumber.length < 10) 
            {
                res.send({ message: "oops!fill your complete mobile number" });
            }else{
        const { mobNumber } = req.body;
        User.findOne({ mobNumber }).then((data) => {
            res.send({ yourProfile: data });
        }).catch((err) => {
            res.send({ message: "something went wrong" });
        })
    }});


//*************************************************************************************************************************************
//******************************** Endpoint to issue new book***********************************************************************
//************************************************************************************************************************************* 

    app.get("/issue", async (req, res) => {
        if (req.body.mobNumber.length < 10) 
            {
                res.send({ message: "oops!fill your complete mobile number" }); //validating moblile number
            }
        const { mobNumber, title } = req.body;
        try {
            const issue = req.query.issue;
            let user = await User.findOne({ mobNumber });  //finding user from entered mobile number in our database
            const bookCount = user.bookCount;
            let book_user_array = user.bookIssued;
            let title_check = await Book.findOne({ title });   //validating title 
            const book_stock = title_check.stock;
            if (!title_check) 
                {
                    res.send({ message: "please enter correct title" }); 
                }

            else
           
            if (book_stock == 0)   //checking availablity of book 
                {
                    res.send({ message: "oops! the book is not avalable at this moment" })
                }
            else
            if (bookCount >= 2)  //limiting user to issue not more than 2 books
                {
                    res.send({ message: "oops! you cannot issue more than 2 books " })
                }

            else

            if ((bookCount < 3) && (book_stock > 0) && (issue == 'confirm')) 
                {
                    let count_user_book = bookCount + 1;            //incrementing books for updating user schema
                    let count_stock_book = book_stock - 1;          //subtracting 1 from count of stock for books
                    book_user_array.push(title_check.title);        //pushing book's title into user's issued book's list
                    //console.log(book_user_array);
                    let updated_data_count = await User.update({ mobNumber: req.body.mobNumber }, { $set: { bookCount: count_user_book } }); //upadating bookcount in user's profile
                    let update_book_issue = await User.update({ mobNumber: req.body.mobNumber }, { $set: { bookIssued: book_user_array } }); //updating booklist's array in user's profile
                    let updated_data_issue = await Book.update({ title: req.body.title }, { $set: { stock: count_stock_book } });  //updating stock of book's inventory

                    let updated_user = await User.findOne({ mobNumber });
                    let updated_title = await Book.findOne({ title });
                    //console.log(updated_user);
                    //console.log(updated_title);
                    res.status(200).send({ message: "you have sucessfully issued book titled " + updated_title.title ,updated_user});
                } 
            else{
                res.send(user);}
        } 
         catch (err) 
         {
            console.log(err);
            res.send({ message: "something went wrong" });
         }

    });


//*************************************************************************************************************************************
//***********************************************Endpoint to return issued book********************************************************
//************************************************************************************************************************************* 


    app.get("/return", async (req, res) => {
        if (req.body.mobNumber.length < 10) {
            res.send({ message: "oops!fill your complete mobile number" });  //validating entered mobile number
        }
        const { mobNumber, title } = req.body;
        try {
            const returning = req.query.return;
            let user = await User.findOne({ mobNumber });  //searching for user from entered mobile number
            //console.log(user);
            let bookCount = user.bookCount;
            //console.log(bookCount);

            if (!user)                      //validating user
                {
                    res.send({ message: "user does not exist" });  
                }

            let title_in_booklist = await Book.findOne({ title });
            //console.log(title_in_booklist);
            let stock_count = title_in_booklist.stock;

            if (!title_in_booklist)          //validating book title
                {
                    res.send({ message: "incorrect book details" });
                }

            let user_issued_book_list = user.bookIssued;
            console.log(user_issued_book_list);
            if ((user_issued_book_list.includes(title)) && (title_in_booklist) && (returning == 'confirm')) 
                {
                    stock_count = stock_count + 1;  //incrementing book's stock as user is returnig issued book
                    bookCount = bookCount - 1;   //subtratcing 1 book from user's book's count
                    user_issued_book_list = user_issued_book_list.filter(item => item !== title); // removing title of returning book fro user's booklist array
                    //console.log(user_issued_book_list);
                    let updated_data_count = await User.update({ mobNumber: req.body.mobNumber }, { $set: { bookCount: bookCount } });   //updating database for user's bookcount in user scheam
                    let update_book_issue = await User.update({ mobNumber: req.body.mobNumber }, { $set: { bookIssued: user_issued_book_list } }) //updating user's booklist array book array
                    let updated_data_issue = await Book.update({ title: req.body.title }, { $set: { stock: stock_count } });  //updating inventory (stock) in book schema
                    let updated_user = await User.findOne({ mobNumber });
                    let updated_title = await Book.findOne({ title });
                    //console.log(updated_user);
                    //console.log(updated_title);

                    res.send({ message: "you have sucessfully returned book titled " + updated_title.title,updated_user });
                } 
            else
                res.send(user)
        }
        catch (err) {
            console.log(err);
            res.send({ message: "something went wrong" });
        }
    })
}

module.exports = appRouter