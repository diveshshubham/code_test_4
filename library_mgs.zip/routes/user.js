const express = require("express");
const Book = require('../models/book');
const router = express.Router();
const User = require('../models/user');

router.get("/allBooks",(req,res)=>{
    Book.find().sort({ title: 1 }).then((data) => {
        res.send({ Allbooks: data });
    }).catch((err) => {
        res.send({ message: err.message || "something went worng" })
    });    

})

router.get("/yourProfile",(req,res)=>{
    if(req.body.mobile_no.length()<10){

        res.send({message: "oops!fill your complete mobile number"});
    
    }
    //const {mobile_no}=req.body;
     User.find({mobile_no:req.body.mobile_no}).then((data)=>{
         res.send({yourProfile: data});
     }).catch((err)=>{
         res.send({message:err.message || "something went wrong"});
     })


});
