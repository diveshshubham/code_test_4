const express  = require('express');
const body_parser = require('body-parser');
const initiateMongo = require('./config/database');
var bodyParser = require("body-parser");

initiateMongo(); //startin mongo db


const app = express();

const port = process.env.PORT || 8083; // defining port

app.use(body_parser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get("/", (req, res) => {
    res.json({ message: "Welcome to simple library :) ! keep reading and sharing knowledge" }); //default message 
});

const endpoints = require('./routes/librarian')(app);

app.listen(port,()=>{
    console.log("server is listening to " +port);
});